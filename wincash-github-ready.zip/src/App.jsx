\
import React, { useEffect, useMemo, useState } from 'react';
import { PieChart, Pie, Tooltip, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts';

const currency = (n) => (n || 0).toLocaleString('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const parseAmount = (v) => Number(String(v).replace(/[^0-9.-]/g, '')) || 0;
const monthKey = (d) => new Date(d).toISOString().slice(0,7);
const uid = () => Math.random().toString(36).slice(2);

const defaultCategories = {
  Pemasukan: ['Gaji','Usaha','Affiliate','Lainnya'],
  Pengeluaran: ['Makan','Transport','Skincare','Hiburan','Tagihan','Cicilan','Lainnya']
};

const starterData = [
  { id: uid(), date: '2025-08-01', type: 'Pemasukan', category: 'Gaji', amount: 5000000, note: 'Gaji Bulanan' },
  { id: uid(), date: '2025-08-02', type: 'Pengeluaran', category: 'Makan', amount: 50000, note: 'Sarapan' },
  { id: uid(), date: '2025-08-03', type: 'Pengeluaran', category: 'Transport', amount: 20000, note: 'Ojol' },
  { id: uid(), date: '2025-08-05', type: 'Pemasukan', category: 'Affiliate', amount: 1500000, note: 'Komisi TikTok' },
];

export default function App(){
  const [transactions, setTransactions] = useState(() => {
    const s = localStorage.getItem('wincash.transactions');
    return s ? JSON.parse(s) : starterData;
  });
  const [cats, setCats] = useState(() => {
    const s = localStorage.getItem('wincash.categories');
    return s ? JSON.parse(s) : defaultCategories;
  });
  const [filterMonth, setFilterMonth] = useState(() => new Date().toISOString().slice(0,7));
  const [newTx, setNewTx] = useState({ date: new Date().toISOString().slice(0,10), type: 'Pengeluaran', category: 'Makan', amount: '', note: '' });
  const [budgetRules, setBudgetRules] = useState(() => {
    const s = localStorage.getItem('wincash.budgetRules');
    return s ? JSON.parse(s) : [
      { key: 'kebutuhan', label: 'Kebutuhan (50%)', percent: 50 },
      { key: 'keinginan', label: 'Keinginan (30%)', percent: 30 },
      { key: 'tabungan', label: 'Tabungan (20%)', percent: 20 },
    ];
  });
  const [catToRule, setCatToRule] = useState(() => {
    const s = localStorage.getItem('wincash.catToRule');
    return s ? JSON.parse(s) : { Makan: 'kebutuhan', Transport: 'kebutuhan', Skincare: 'keinginan', Hiburan: 'keinginan' };
  });
  const [goals, setGoals] = useState(() => {
    const s = localStorage.getItem('wincash.goals');
    return s ? JSON.parse(s) : [{ id: uid(), title: 'Dana Darurat', target: 10000000, saved: 3000000 }];
  });

  useEffect(()=> localStorage.setItem('wincash.transactions', JSON.stringify(transactions)), [transactions]);
  useEffect(()=> localStorage.setItem('wincash.categories', JSON.stringify(cats)), [cats]);
  useEffect(()=> localStorage.setItem('wincash.budgetRules', JSON.stringify(budgetRules)), [budgetRules]);
  useEffect(()=> localStorage.setItem('wincash.catToRule', JSON.stringify(catToRule)), [catToRule]);
  useEffect(()=> localStorage.setItem('wincash.goals', JSON.stringify(goals)), [goals]);

  const filtered = useMemo(()=> transactions.filter(t => monthKey(t.date) === filterMonth), [transactions, filterMonth]);

  const totals = useMemo(()=> {
    const income = filtered.filter(t => t.type === 'Pemasukan').reduce((a,b)=>a+b.amount,0);
    const expense = filtered.filter(t => t.type === 'Pengeluaran').reduce((a,b)=>a+b.amount,0);
    return { income, expense, balance: income-expense };
  }, [filtered]);

  const expenseByCat = useMemo(()=> {
    const map = {};
    filtered.filter(t => t.type === 'Pengeluaran').forEach(t => { map[t.category] = (map[t.category]||0) + t.amount; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [filtered]);

  const expensePercentByCat = useMemo(()=>{
    const income = totals.income || 0;
    if (income === 0) return expenseByCat.map(e => ({ ...e, percentOfIncome: 0 }));
    return expenseByCat.map(e => ({ ...e, percentOfIncome: Math.round((e.value / income) * 100) }));
  }, [expenseByCat, totals.income]);

  const budgetSpend = useMemo(()=> {
    const map = {};
    filtered.filter(t => t.type === 'Pengeluaran').forEach(t => {
      const rule = catToRule[t.category] || 'lainnya';
      map[rule] = (map[rule]||0) + t.amount;
    });
    return budgetRules.map(r => ({ ...r, spent: map[r.key] || 0 }));
  }, [filtered, catToRule, budgetRules]);

  const monthlySeries = useMemo(()=> {
    const map = {};
    transactions.forEach(t => {
      const m = monthKey(t.date);
      if (!map[m]) map[m] = { month: m, pemasukan: 0, pengeluaran: 0, saldo: 0 };
      if (t.type === 'Pemasukan') map[m].pemasukan += t.amount; else map[m].pengeluaran += t.amount;
    });
    return Object.values(map).sort((a,b)=>a.month.localeCompare(b.month)).map(m => ({ ...m, saldo: m.pemasukan - m.pengeluaran }));
  }, [transactions]);

  function addTransaction(e){
    e.preventDefault();
    const amount = parseAmount(newTx.amount);
    if (!newTx.date || !newTx.type || !newTx.category || amount <= 0) return;
    setTransactions(prev => [{ id: uid(), date: newTx.date, type: newTx.type, category: newTx.category, amount, note: newTx.note }, ...prev]);
    setNewTx({ date: newTx.date, type: newTx.type, category: newTx.category, amount: '', note: '' });
  }
  function removeTransaction(id){ setTransactions(prev => prev.filter(t => t.id !== id)); }
  function addCategory(type){ const name = prompt(`Tambah kategori ${type}? (tulis nama)`); if(!name) return; setCats(prev => ({ ...prev, [type]: Array.from(new Set([...(prev[type]||[]), name])) })); }
  function exportCSV(){ const headers = ['Tanggal','Jenis','Kategori','Nominal','Catatan']; const rows = transactions.map(t => [t.date,t.type,t.category,t.amount,t.note]); const csv = [headers.join(','), ...rows.map(r=>r.join(','))].join('\n'); const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `wincash_transaksi_${Date.now()}.csv`; a.click(); URL.revokeObjectURL(url); }
  function importCSV(e){ const file = e.target.files?.[0]; if(!file) return; const reader = new FileReader(); reader.onload = ()=>{ const text = reader.result; const lines = String(text).trim().split(/\\r?\\n/); const body = lines.slice(1); const imported = body.map(line=>{ const [date,type,category,amount,note] = line.split(','); return { id: uid(), date, type, category, amount: parseAmount(amount), note }; }).filter(t=>t.date && t.type); setTransactions(prev => [...imported, ...prev]); e.target.value = ''; }; reader.readAsText(file); }
  function resetAll(){ if(!confirm('Hapus semua data dan kembali ke contoh?')) return; setTransactions(starterData); setCats(defaultCategories); setBudgetRules([ { key: 'kebutuhan', label: 'Kebutuhan (50%)', percent: 50 }, { key: 'keinginan', label: 'Keinginan (30%)', percent: 30 }, { key: 'tabungan', label: 'Tabungan (20%)', percent: 20 } ]); setCatToRule({ Makan: 'kebutuhan', Transport: 'kebutuhan', Skincare: 'keinginan', Hiburan: 'keinginan' }); setGoals([{ id: uid(), title: 'Dana Darurat', target: 10000000, saved: 3000000 }]); }

  function editBudgetRulePercent(key){
    const val = prompt('Masukkan persentase baru untuk rule tersebut (angka saja)');
    const n = Number(val);
    if (isNaN(n) || n<0 || n>100) return alert('Persentase tidak valid');
    setBudgetRules(prev => prev.map(r => r.key===key ? { ...r, percent: n, label: `${r.label.split('(')[0].trim()} (${n}%)` } : r));
  }
  function assignCategoryToRule(category){
    const ruleKey = prompt(`Masukkan key rule untuk kategori ${category} (contoh: kebutuhan, keinginan, tabungan)`);
    if(!ruleKey) return;
    setCatToRule(prev => ({ ...prev, [category]: ruleKey }));
  }
  function addGoal(){ const title = prompt('Nama tujuan'); const target = Number(prompt('Target nominal (angka saja, tanpa titik)')||0); if(!title||isNaN(target)||target<=0) return alert('Input tidak valid'); setGoals(prev => [{ id: uid(), title, target, saved: 0 }, ...prev]); }
  function editGoalSaved(id){ const g = goals.find(x=>x.id===id); if(!g) return; const saved = Number(prompt('Sudah terkumpul (angka saja)', String(g.saved))||0); setGoals(prev => prev.map(x => x.id===id ? { ...x, saved } : x)); }

  return (
    <div className="container">
      <header className="header">
        <div className="brand">
          <div className="logo">W</div>
          <div>
            <div style={{fontWeight:700}}>winCash</div>
            <div className="small">Atur duit makin gampang, hidup makin tenang</div>
          </div>
        </div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <button className="btn" onClick={exportCSV}>Export CSV</button>
          <input id="import" type="file" accept=".csv" style={{display:'none'}} onChange={importCSV} />
          <button className="btn" onClick={()=>document.getElementById('import').click()}>Import</button>
          <button className="btn" style={{background:'#ff6b6b'}} onClick={resetAll}>Reset</button>
        </div>
      </header>

      <div className="grid">
        <div className="card">
          <h3>Tambah Transaksi</h3>
          <form onSubmit={addTransaction} style={{marginTop:8, display:'grid', gap:8}}>
            <input className="input" type="date" value={newTx.date} onChange={e=>setNewTx({...newTx, date:e.target.value})} required />
            <div style={{display:'flex',gap:8}}>
              <select className="input" value={newTx.type} onChange={e=>setNewTx({...newTx, type:e.target.value, category: (cats[e.target.value]?.[0]||'')})}>
                <option value="Pemasukan">Pemasukan</option>
                <option value="Pengeluaran">Pengeluaran</option>
              </select>
              <select className="input" value={newTx.category} onChange={e=>setNewTx({...newTx, category:e.target.value})}>
                {(cats[newTx.type]||[]).map(c=> <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <input className="input" placeholder="Nominal" value={newTx.amount} onChange={e=>setNewTx({...newTx, amount:e.target.value})} />
            <input className="input" placeholder="Catatan (opsional)" value={newTx.note} onChange={e=>setNewTx({...newTx, note:e.target.value})} />
            <div style={{display:'flex',gap:8}}>
              <button className="btn" type="submit">Tambah</button>
              <button type="button" className="btn" style={{background:'#eee',color:'#111'}} onClick={()=>addCategory(newTx.type)}>Tambah Kategori</button>
            </div>

            <div style={{marginTop:12}}>
              <h4>Budget Rules</h4>
              <div style={{display:'grid',gap:8, marginTop:8}}>
                {budgetRules.map(rule=> {
                  const limit = Math.round((rule.percent/100)*(totals.income||0));
                  const spent = budgetSpend.find(b=>b.key===rule.key)?.spent || 0;
                  const pctUsed = limit===0?0:Math.round((spent/limit)*100);
                  return (
                    <div key={rule.key} className="card" style={{padding:10}}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                        <div>
                          <div style={{fontWeight:600}}>{rule.label}</div>
                          <div className="small">{currency(spent)} / {currency(limit)}</div>
                        </div>
                        <div>
                          <button className="small" onClick={()=>editBudgetRulePercent(rule.key)}>Edit %</button>
                        </div>
                      </div>
                      <div className="progress" style={{marginTop:8}}>
                        <div style={{width: Math.min(pctUsed,200) + '%'}}></div>
                      </div>
                      <div className="small" style={{marginTop:6}}>{pctUsed}% dari limit</div>
                    </div>
                  );
                })}
                <div className="small">Tip: atur pengalokasian kategori ke rule agar perhitungan otomatis.</div>
              </div>
            </div>

          </form>
        </div>

        <div>
          <div className="card" style={{marginBottom:12}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <div>
                <div className="small">Bulan</div>
                <input type="month" value={filterMonth} onChange={e=>setFilterMonth(e.target.value)} className="input" />
              </div>
              <div style={{display:'flex',gap:8}}>
                <div className="card"><div className="small">Pemasukan</div><div style={{fontWeight:700}}>{currency(totals.income)}</div></div>
                <div className="card"><div className="small">Pengeluaran</div><div style={{fontWeight:700}}>{currency(totals.expense)}</div></div>
                <div className="card"><div className="small">Saldo</div><div style={{fontWeight:700}}>{currency(totals.balance)}</div></div>
              </div>
            </div>

            <div style={{marginTop:12}}>
              <h4>Pengeluaran — Persentase terhadap pemasukan</h4>
              <div style={{display:'grid',gap:8, marginTop:8}}>
                {expensePercentByCat.map(e => (
                  <div key={e.name} className="card" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    <div>
                      <div style={{fontWeight:600}}>{e.name}</div>
                      <div className="small">{currency(e.value)}</div>
                    </div>
                    <div className="small">{e.percentOfIncome}%</div>
                  </div>
                ))}
                {expensePercentByCat.length===0 && <div className="small">Belum ada pengeluaran bulan ini atau pemasukan = 0</div>}
              </div>
            </div>
          </div>

          <div className="card" style={{marginBottom:12}}>
            <h4>Pengeluaran per Kategori</h4>
            <div style={{height:240}}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={expenseByCat} dataKey="value" nameKey="name" innerRadius={40} outerRadius={80}>
                  </Pie>
                  <Tooltip formatter={(v)=>currency(v)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card">
            <h4>Tren Bulanan</h4>
            <div style={{height:200}}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlySeries}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(v)=>currency(v)} />
                  <Line type="monotone" dataKey="pemasukan" dot={false} strokeWidth={2} />
                  <Line type="monotone" dataKey="pengeluaran" dot={false} strokeWidth={2} stroke="#ff6b6b" />
                  <Line type="monotone" dataKey="saldo" dot={false} strokeWidth={2} stroke="#4ade80" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card" style={{marginTop:12}}>
            <h4>Daftar Transaksi</h4>
            <table className="table">
              <thead><tr><th>Tanggal</th><th>Jenis</th><th>Kategori</th><th>Nominal</th><th>Catatan</th><th>Aksi</th></tr></thead>
              <tbody>
                {filtered.length===0 && <tr><td colSpan={6} className="small">Belum ada transaksi di bulan ini.</td></tr>}
                {filtered.map(tx => (
                  <tr key={tx.id}>
                    <td>{tx.date}</td>
                    <td>{tx.type}</td>
                    <td>{tx.category}</td>
                    <td style={{textAlign:'right'}}>{currency(tx.amount)}</td>
                    <td>{tx.note}</td>
                    <td><button className="small" onClick={()=>removeTransaction(tx.id)}>Hapus</button></td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div style={{marginTop:12}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <h4>Goals</h4>
                <button className="btn" onClick={addGoal}>Tambah Goal</button>
              </div>
              <div style={{display:'grid',gap:8,marginTop:8}}>
                {goals.map(g => {
                  const pct = g.target===0?0:Math.round((g.saved/g.target)*100);
                  return (
                    <div key={g.id} className="card" style={{padding:10}}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                        <div>
                          <div style={{fontWeight:600}}>{g.title}</div>
                          <div className="small">{currency(g.saved)} / {currency(g.target)}</div>
                        </div>
                        <div><button className="small" onClick={()=>editGoalSaved(g.id)}>Edit</button></div>
                      </div>
                      <div className="progress" style={{marginTop:8}}>
                        <div style={{width: Math.min(pct,100) + '%'}}></div>
                      </div>
                      <div className="small">{pct}% tercapai</div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

        </div>
      </div>

      <footer className="footer">© {new Date().getFullYear()} winCash • Dibuat untuk dijual kembali (boleh rebrand)</footer>
    </div>
  );
}
