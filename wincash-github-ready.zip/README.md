winCash PWA & GitHub Actions (ready-to-upload)
=============================================

Isi repo ini:
- PWA React (vite) source: src/
- manifest.webmanifest, service-worker.js
- .github/workflows/wincash-apk.yml -> workflow otomatis build & deploy ke GitHub Pages, lalu build APK via Bubblewrap (requires secrets).
- twa-manifest.json -> TWA manifest used by Bubblewrap
- README & how-to files

Langkah singkat upload ke GitHub (GUI):
1. Masuk ke repo GitHub kamu (misal: username/wincash).
2. Klik 'Add file' -> 'Upload files'.
3. Upload semua file/folder di dalam ZIP ini (ekstrak dulu di komputer kamu, lalu drag & drop semua file).
4. Commit changes.
5. Buka tab 'Actions' -> jalankan workflow 'wincash-apk' (atau tunggu push ke branch main).

Catatan penting:
- Untuk APK signed otomatis: tambahkan secrets di repo (Settings -> Secrets -> Actions):
  - KEYSTORE_BASE64 (base64 dari file keystore)
  - KEYSTORE_PASSWORD
  - KEY_ALIAS
  - KEY_PASSWORD
- Jika belum punya host PWA, workflow akan deploy ke GitHub Pages (https://{owner}.github.io/{repo}) lalu Bubblewrap akan gunakan URL tersebut.
